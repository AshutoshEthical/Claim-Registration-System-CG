package com.cg.dao;

import com.cg.dto.CreateClaim;
import com.cg.dto.User;
import com.cg.exception.ICRException;

public interface IUserDAO {
	
	public int addUser(User userDTO) throws ICRException;
	
	public int createClaim(CreateClaim createClaim) throws ICRException;
	
}

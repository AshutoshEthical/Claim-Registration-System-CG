package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.cg.dto.Policy;
import com.cg.dto.UserRole;
import com.cg.exception.ICRException;
import com.cg.utiliy.JdbcUtility;

public class AdminDAO implements IAdminDAO {

	static final Logger LOGGER = Logger.getLogger(AdminDAO.class);
	static Connection connection = null;

	@Override
	public int addAdmin(UserRole adminDTO) throws ICRException {
		int Error = -1;
		int rows = 0;
		try {

			connection = JdbcUtility.getConnection();
			LOGGER.info("Connection establised");

			PreparedStatement ps = connection.prepareStatement(QueryConstants.ADDROLE);
			ps.setString(1, adminDTO.getUserName());
			ps.setString(2, adminDTO.getPassword());
			ps.setString(3, adminDTO.getRoleCode());
			rows = ps.executeUpdate();
			LOGGER.info("Query Executed successfully");

		} catch (ICRException | SQLException e) {
			LOGGER.error("Problem in addadmin method in adminDao");
			return Error;
			// throw new ICRException(e.getMessage()+"problem occured in addagent DAO");
		}
		return rows;
	}

	@Override
	public String validate(UserRole userDTO) throws ICRException {
		boolean status = false;
		String roleCode = "";
		try {
			connection = JdbcUtility.getConnection();
			LOGGER.info("Connection Established");
			PreparedStatement ps = connection.prepareStatement(QueryConstants.VALIDATE);
			ps.setString(1, userDTO.getUserName());
			ps.setString(2, userDTO.getPassword());

			ResultSet rs = ps.executeQuery();

			if (rs.next())
				roleCode = rs.getString(1);
			System.out.println("AdminDAO :" + roleCode);
		} catch (ICRException | SQLException e) {
			LOGGER.error("Problem in validate method in adminDao");
			throw new ICRException(e.getMessage() + "Problem Occured in AdminDAO during login");
		}
		return roleCode;
	}

	@Override
	public int addPolicy(Policy policyDTO) throws ICRException {
		int rows = 0;
		try {

			connection = JdbcUtility.getConnection();
			PreparedStatement ps = null;
			ResultSet rs = null;

			ps = connection.prepareStatement(QueryConstants.GETACCOUNTNO);
			ps.setString(1, policyDTO.getUserName());
			System.out.println(policyDTO.getUserName());
			rs = ps.executeQuery();
			System.out.println("In AdminDAO add policy ()" + rs.next());
			long accountNo = rs.getLong("accountno");
			System.out.println("accno:");
			ps = connection.prepareStatement(QueryConstants.ADDPOLICY1);
			ps.setInt(1, policyDTO.getPolicyNo());
			ps.setLong(2, policyDTO.getPremAmount());
			ps.setLong(3, accountNo);
			ps.setString(4, policyDTO.getPolicy());
			rows = ps.executeUpdate();

			System.out.println("after add policy1" + rows);
			ps = connection.prepareStatement(QueryConstants.ADDPOLICY);
			ps.setString(1, policyDTO.getUserName());
			ps.setInt(2, policyDTO.getPolicyNo());
			rows = ps.executeUpdate();

			System.out.println("after add policy" + rows);

		} catch (ICRException | SQLException e) {
			// return Error;
			LOGGER.error("Problem in addpolicy method in adminDao");
			throw new ICRException(e.getMessage() + "problem occured in addagent DAO");
		}
		return rows;
	}

}

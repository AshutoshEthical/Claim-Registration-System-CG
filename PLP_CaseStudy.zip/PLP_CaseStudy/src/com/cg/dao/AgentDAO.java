package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.cg.dto.AddUserToAgent;
import com.cg.dto.CreateClaim;
import com.cg.dto.UserRole;
import com.cg.exception.ICRException;
import com.cg.utiliy.JdbcUtility;

public class AgentDAO implements IAgentDAO {
	static final Logger LOGGER = Logger.getLogger(AgentDAO.class);

	@Override
	public int addAgent(UserRole agentDTO) throws ICRException {

		Connection connection = null;
		PreparedStatement statement = null;
		int rows = 0;
		int Error = -1;
		try {
			connection = JdbcUtility.getConnection();
			LOGGER.info("Connection established");
			PreparedStatement ps = connection.prepareStatement(QueryConstants.ADDROLE);
			ps.setString(1, agentDTO.getUserName());
			ps.setString(2, agentDTO.getPassword());
			ps.setString(3, agentDTO.getRoleCode());

			rows = ps.executeUpdate();
			System.out.println("rows" + rows);
			LOGGER.info("Query Executed successfully");
		} catch (ICRException | SQLException e) {
			LOGGER.error("Problem in addagent method in agentDao");
			return Error;
			// throw new ICRException(e.getMessage()+"problem occured in addagent DAO");
		}
		return rows;
	}

	@Override
	public int createClaim(CreateClaim createClaim) throws ICRException {
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet rs = null;
		int rows = 0;
		int Error = -1;
		try {
			connection = JdbcUtility.getConnection();
			LOGGER.info("Connection established");
			PreparedStatement ps = connection.prepareStatement(QueryConstants.ADDCLAIM);
			ps.setString(1, createClaim.getReason());
			ps.setString(2, createClaim.getLocation());
			ps.setString(3, createClaim.getCity());
			ps.setString(4, createClaim.getState());
			ps.setInt(5, createClaim.getZip());
			ps.setString(6, createClaim.getClaimType());
			ps.setInt(7, createClaim.getPolicyNo());
			rows = ps.executeUpdate();
			System.out.println("rows" + rows);

			ps = connection.prepareStatement(QueryConstants.GETCLAIMNO);
			ps.setInt(1, createClaim.getPolicyNo());
			rs = ps.executeQuery();
			rs.next();
			int claimNo = rs.getInt("claimno");

			ps = connection.prepareStatement(QueryConstants.ADDSTATUS);
			ps.setInt(1, claimNo);
			ps.setString(2, "pending");
			rows = ps.executeUpdate();
			System.out.println("rows" + rows);
			LOGGER.info("Query Executed successfully");
		} catch (ICRException | SQLException e) {
			LOGGER.error("Problem in createClaim method in agentDao");
			return Error;
			// throw new ICRException(e.getMessage()+"problem occured in creating claim ,
			// AGENTdao");
		}
		return rows;

	}

	@Override
	public int addUserToAgent(AddUserToAgent addDTO) throws ICRException {
		Connection connection = null;
		PreparedStatement statement = null;
		int Error = -1;
		int rows = 0;
		try {
			connection = JdbcUtility.getConnection();
			LOGGER.info("Connection established");
			PreparedStatement ps = connection.prepareStatement(QueryConstants.ADDUSERTOAGENT);
			ps.setString(1, addDTO.getAgentId());
			ps.setString(2, addDTO.getUserName());

			rows = ps.executeUpdate();
			System.out.println("rows" + rows);
			LOGGER.info("Query Executed successfully");
		} catch (ICRException | SQLException e) {
			LOGGER.error("Problem in addUserToAgent method in agentDao");
			return Error;
			// throw new ICRException(e.getMessage()+"problem occured in addagent DAO");
		}
		return rows;
	}
}
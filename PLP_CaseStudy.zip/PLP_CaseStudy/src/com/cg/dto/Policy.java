package com.cg.dto;

public class Policy {

	private String userName;
	private String policy;
	private long premAmount;
	private int policyNo;

	public Policy(String userName, String policy, long premAmount, int policyNo) {
		super();
		this.userName = userName;
		this.policy = policy;
		this.premAmount = premAmount;
		this.policyNo = policyNo;
	}

	public Policy() {
		super();
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPolicy() {
		return policy;
	}

	public void setPolicy(String policy) {
		this.policy = policy;
	}

	public long getPremAmount() {
		return premAmount;
	}

	public void setPremAmount(long premAmount) {
		this.premAmount = premAmount;
	}

	public int getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(int policyNo) {
		this.policyNo = policyNo;
	}

}

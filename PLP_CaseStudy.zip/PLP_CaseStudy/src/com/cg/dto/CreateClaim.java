package com.cg.dto;

public class CreateClaim {
	private String reason;
	private String location;
	private String city;
	private String state;
	private int zip;
	private String claimType;
	private int policyNo;

	public CreateClaim() {
		super();
	}

	public CreateClaim(String reason, String location, String city, String state, int zip, String claimType,
			int policyNo) {
		super();
		this.reason = reason;
		this.location = location;
		this.city = city;
		this.state = state;
		this.zip = zip;
		this.claimType = claimType;
		this.policyNo = policyNo;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public int getZip() {
		return zip;
	}

	public void setZip(int zip) {
		this.zip = zip;
	}

	public String getClaimType() {
		return claimType;
	}

	public void setClaimType(String claimType) {
		this.claimType = claimType;
	}

	public int getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(int policyNo) {
		this.policyNo = policyNo;
	}

}

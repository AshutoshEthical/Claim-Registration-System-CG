package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.cg.dao.AdminDAO;
import com.cg.dao.IAdminDAO;
import com.cg.dao.IUserDAO;
import com.cg.dao.UserDAO;
import com.cg.dto.Policy;
import com.cg.exception.ICRException;

@WebServlet("/addPolicy")
public class AddPolicyServlet extends HttpServlet {
	static final Logger LOGGER = Logger.getLogger(AddPolicyServlet.class);

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		if (request.getSession().getAttribute("username") == null) {
			LOGGER.info("Session not established");
			response.sendRedirect("index.jsp");

		} else {
			if (request.getSession().getAttribute("rolecode").equals("usr")) {
				LOGGER.info("Redirected to user home page");
				response.sendRedirect("userHomePage.jsp");
			} else if (request.getSession().getAttribute("rolecode").equals("agnt")) {
				LOGGER.info("Redirected to agent home page");
				response.sendRedirect("agentHomePage.jsp");
			}
		}

	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		try {
			
			String userName = request.getParameter("username");
			String policy = request.getParameter("policy");
			long premAmount = Long.parseLong(request.getParameter("premamount"));
			int policyNo = Integer.parseInt(request.getParameter("policyno"));

			RequestDispatcher dispatcher = null;
			out.println("<html><body>");
			LOGGER.info("Retrieved values of addPolicy ");
			Policy policyDTO = new Policy(userName, policy, premAmount, policyNo);
			IAdminDAO user = new AdminDAO();

			int rows = 0;

			rows = user.addPolicy(policyDTO);
			System.out.println("AddPolicyServlet " + rows);
			if (rows > 0) {
				LOGGER.info("Policy assigned to user");
				response.setHeader("Refresh", "1;url=vieClaimsAdmin.jsp");
			} else if (rows == -1)
				response.sendRedirect("AdminError.jsp");
			else {
				LOGGER.info("Policy Not added");
				out.println("policy not added");
			}
		} catch (Exception e) {
			LOGGER.error("Exception in add policy servlet");
			response.sendRedirect("AdminError.jsp");
			System.out.println(e.getMessage() + " exception in add policy servlet");
		}
	}

}
